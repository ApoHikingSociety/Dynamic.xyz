Credit : @RyzekGaming (Youtube)

How To USE : Copy all files of folder "Minecraft Files" and paste to C:\XboxGames\Minecraft for Windows\Content

NOTE : The XboxGames's location can differ depending upon where you have installed Minecraft Like C:,D:, etc.